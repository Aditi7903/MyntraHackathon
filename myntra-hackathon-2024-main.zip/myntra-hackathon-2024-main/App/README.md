# Website

In order to run the website, follow the steps given below:
- Clone this repository
- Switch to the frontend folder: `./App/frontend`
- Make sure you have react and react-router-dom installed into your system.
- Run the command `npm start` to launch the website.

The website will be visible on your local system.
