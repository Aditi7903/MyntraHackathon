# Introduction

This repository contains the code to the Frontend and TryOn feature of our proposed solution.

The App contains the code to the website.

The TrendAI contains a Jupyter notebook which has the code for the Trend Generation feature.

Please switch to the given folders to find instructions on how to run them.
