# TRENDAI

In order to run the TrendAI feature, follow the steps given below:

If the system has a GPU:
- Clone the repository
- Adjust the prompt given according to the parameters inputed in the website.
- Run the Jupyter notebook by pressing the run all button.

The image would be outputted. Having more powerful GPUs would result in faster results. 

In case a GPU is not present, open the following Google Colab link.

https://colab.research.google.com/drive/1JDAu6xmOHlzYKK9y0Hq53kw111xlFcY7?usp=sharing

Set the runtime type as GPU and run the cells. The prompt can be adjusted by the user.
